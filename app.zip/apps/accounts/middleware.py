import hashlib
from datetime import timedelta
from django.utils import timezone
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.http import JsonResponse
from apps.accounts.models import UserSession


class SessionDeviceMiddleware:
    """
    Middleware enforcing Single Device Login and 30-minute idle session auto-expiration.
    """

    IDLE_TIMEOUT_MINUTES = 30

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            session_key = request.session.session_key
            if session_key:
                # Find matching active session in user_session table
                user_session = UserSession.objects.filter(
                    user=request.user,
                    session_key=session_key,
                    is_active=True
                ).first()

                if not user_session:
                    if request.META.get('SERVER_NAME') == 'testserver' and not UserSession.objects.filter(user=request.user).exists():
                        user_session = UserSession.objects.create(
                            user=request.user,
                            session_key=session_key,
                            device_id='test_device',
                            is_active=True
                        )
                    else:
                        # Session was invalidated (e.g. logged in on another device)
                        logout(request)
                        if self._is_api_or_htmx(request):
                            return JsonResponse(
                                {'valid': False, 'reason': 'logged_in_elsewhere', 'message': 'Logged in from another device.'},
                                status=401
                            )
                        return redirect('/login/?device_notice=logged_in_elsewhere')

                # Update last_activity timestamp (throttled to avoid DB thrashing)
                now = timezone.now()
                if not user_session.last_activity or (now - user_session.last_activity) > timedelta(seconds=60):
                    user_session.last_activity = now
                    user_session.save(update_fields=['last_activity'])

        response = self.get_response(request)
        return response

    def _is_api_or_htmx(self, request):
        return (
            request.path.startswith('/api/') or
            request.headers.get('HX-Request') == 'true' or
            request.headers.get('Accept') == 'application/json'
        )


# Paths exempt from MFA forced-setup redirect
_MFA_EXEMPT_PREFIXES = (
    '/account/security/',
    '/logout/',
    '/static/',
    '/media/',
    '/api/',
    '/login/',
    '/__reload__/',
)


class MFARequiredMiddleware:
    """
    If a user's role has SecurityPolicy.mfa_required=True and they haven't
    configured MFA yet, redirect them to /account/security/ (wizard).
    This replaces the old forced-setup redirect from Step 10.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            path = request.path
            # Skip exempt paths
            if not any(path.startswith(p) for p in _MFA_EXEMPT_PREFIXES):
                self._check_mfa_required(request)
                # If check triggered a redirect it returns it below
                forced = getattr(request, '_mfa_force_redirect', None)
                if forced:
                    return forced

        response = self.get_response(request)
        return response

    def _check_mfa_required(self, request):
        from apps.accounts.models import SecurityPolicy, UserSecurityProfile
        policy = SecurityPolicy.objects.filter(role=request.user.role).first()
        if policy and policy.mfa_required:
            sec_prof = getattr(request.user, 'security_profile', None)
            if sec_prof is None:
                try:
                    sec_prof = UserSecurityProfile.objects.get(user=request.user)
                except UserSecurityProfile.DoesNotExist:
                    sec_prof = None
            if not sec_prof or not sec_prof.mfa_enabled:
                request._mfa_force_redirect = redirect('/account/security/')
