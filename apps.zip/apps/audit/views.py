from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import HttpResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View

from apps.accounts.mixins import RoleRequiredMixin
from .auth import has_audit_unlock
from .models import AuditEvent, TrashEntry
from .services import AuditService, TrashService


class TrashListView(LoginRequiredMixin, RoleRequiredMixin, View):
    allowed_roles = ["admin", "system_owner", "manager", "hr"]

    template_name = "audit/trash_list.html"
    partial_template_name = "audit/partials/trash_table.html"

    def get_queryset(self, request):
        qs = TrashEntry.objects.select_related("deleted_by", "related_employee").order_by("-deleted_at")
        module = request.GET.get("module", "").strip()
        deleted_by = request.GET.get("deleted_by", "").strip()
        status = request.GET.get("status", TrashEntry.STATUS_ACTIVE).strip()
        search = request.GET.get("q", "").strip()
        if status:
            qs = qs.filter(status=status)
        if module:
            qs = qs.filter(module=module)
        if deleted_by:
            qs = qs.filter(deleted_by__email__icontains=deleted_by)
        if search:
            qs = qs.filter(Q(object_label__icontains=search) | Q(object_id__icontains=search))
        if not request.user.is_superuser and getattr(request.user, "role", "") == "manager":
            emp_master = getattr(request.user, "employee_master", None)
            if emp_master:
                subordinate_ids = list(emp_master.direct_reports.values_list("id", flat=True))
                subordinate_ids.append(emp_master.id)
                qs = qs.filter(Q(related_employee_id__in=subordinate_ids) | Q(deleted_by=request.user))
        return qs

    def get(self, request):
        entries = self.get_queryset(request)
        context = {
            "entries": entries[:150],
            "status_filter": request.GET.get("status", TrashEntry.STATUS_ACTIVE),
            "module_filter": request.GET.get("module", ""),
            "deleted_by_filter": request.GET.get("deleted_by", ""),
            "search_query": request.GET.get("q", ""),
        }
        template = self.partial_template_name if request.headers.get("HX-Request") == "true" else self.template_name
        return render(request, template, context)


class TrashRestoreView(LoginRequiredMixin, RoleRequiredMixin, View):
    allowed_roles = ["admin", "system_owner", "manager", "hr"]

    def post(self, request, pk):
        entry = get_object_or_404(TrashEntry, pk=pk)
        TrashService.restore(entry, actor=request.user, request=request)
        messages.success(request, f"Restored {entry.object_label}.")
        if request.headers.get("HX-Request") == "true":
            response = HttpResponse(status=204)
            response["HX-Redirect"] = request.META.get("HTTP_REFERER", "/audit/trash/")
            return response
        return redirect("audit:trash_list")


class TrashPermanentDeleteView(LoginRequiredMixin, View):
    def post(self, request, pk):
        if not request.user.is_superuser:
            raise PermissionDenied("Only super-admin can permanently delete trashed records.")
        entry = get_object_or_404(TrashEntry, pk=pk)
        try:
            TrashService.permanent_delete(entry, actor=request.user, request=request)
            messages.success(request, f"Permanently deleted {entry.object_label}.")
        except Exception as exc:
            messages.error(request, str(exc))
        if request.headers.get("HX-Request") == "true":
            response = HttpResponse(status=204)
            response["HX-Redirect"] = request.META.get("HTTP_REFERER", "/audit/trash/")
            return response
        return redirect("audit:trash_list")


class TrashBulkActionView(LoginRequiredMixin, View):
    def post(self, request):
        ids = [pk for pk in request.POST.getlist("ids") if pk.isdigit()]
        action = request.POST.get("bulk_action", "").strip()
        entries = TrashEntry.objects.filter(pk__in=ids)
        if action == "restore":
            for entry in entries:
                TrashService.restore(entry, actor=request.user, request=request)
            messages.success(request, f"Restored {entries.count()} trash record(s).")
        elif action == "permanent_delete":
            if not request.user.is_superuser:
                return HttpResponseForbidden("Super-admin only.")
            for entry in entries:
                try:
                    TrashService.permanent_delete(entry, actor=request.user, request=request)
                except Exception:
                    continue
            messages.success(request, f"Processed permanent delete for {entries.count()} trash record(s).")
        elif action == "empty_trash":
            if not request.user.is_superuser:
                return HttpResponseForbidden("Super-admin only.")
            for entry in entries.filter(status=TrashEntry.STATUS_ACTIVE):
                try:
                    TrashService.permanent_delete(entry, actor=request.user, request=request)
                except Exception:
                    continue
            messages.success(request, "Processed Empty Trash request.")
        return redirect("audit:trash_list")


class ActivityListView(LoginRequiredMixin, View):
    template_name = "audit/activity_list.html"
    partial_template_name = "audit/partials/activity_table.html"

    def get_queryset(self, request):
        qs = AuditService.get_scoped_events(request.user)
        module = request.GET.get("module", "").strip()
        action = request.GET.get("action", "").strip()
        search = request.GET.get("q", "").strip()
        if module:
            qs = qs.filter(module=module)
        if action:
            qs = qs.filter(action=action)
        if search:
            qs = qs.filter(
                Q(object_label__icontains=search) |
                Q(object_id__icontains=search) |
                Q(actor_user__email__icontains=search) |
                Q(reason_note__icontains=search)
            )
        return qs

    def get(self, request):
        events = self.get_queryset(request)
        context = {
            "events": events[:150],
            "module_filter": request.GET.get("module", ""),
            "action_filter": request.GET.get("action", ""),
            "search_query": request.GET.get("q", ""),
        }
        template = self.partial_template_name if request.headers.get("HX-Request") == "true" else self.template_name
        return render(request, template, context)


class AuditEventDetailView(LoginRequiredMixin, View):
    template_name = "audit/partials/event_detail.html"

    def get(self, request, pk):
        event = get_object_or_404(AuditService.get_scoped_events(request.user), pk=pk)
        if not has_audit_unlock(request):
            response = render(request, "accounts/partials/reauth_modal.html", {
                "target_url": request.path,
                "reauth_scope": "audit_detail",
                "reauth_title": "Audit Detail Unlock",
                "reauth_help_text": "Confirm your current password or MFA code to view detailed before and after data.",
            })
            response["HX-Trigger"] = "open-reauth-modal"
            return response
        AuditService.log_access(request.user, event, reason="audit_detail_opened", request=request)
        return render(request, self.template_name, {"event": event})

